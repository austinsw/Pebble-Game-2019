Make sure that the current directory is the pebblesTest directory
In order to run the testsuite, 

- if on a Mac run the command:

  java -cp junit-4.12.jar:. TestRunner

- if on Windows run the command:

  java -cp junit-4.12.jar;. TestRunner

The expected output of the test is that all the tests will be passed

